BOOL IsExistFont( HDC dc ,const char* fontname) 
{
	LOGFONT if ;
	memset(&if ,0,sizeof(LOGFONT)) ; 
	
	BOOL result = FALSE ; 
	
	lf.lfCharSet = DEFAULT_CHARSET ; 
	
	strcpy(lf.lfFaceName ,fontname) ; 
}